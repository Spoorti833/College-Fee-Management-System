"FREE SOURCE CODE" How to run the Online_School_Fees_Payment_System_Project 
FIRST DOWNLOAD


1.XAMPP

2."TEXT EDITOR" NOTEPAD++ OR SUBLIME TEXT 3 / ETC.

3."Online_School_Fees_Payment_System_Project"

4. Download the zip file/ download din ng winrar

5. Extract the file and copy "Online_School_Fees_Payment_System_Projectt" folder

6.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

7. Open PHPMyAdmin (http://localhost/phpmyadmin)

8. Create a database with name paysystem

6. Import paysystem.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/Online_School_Fees_Payment_System_Project 

Username: admin
Password: admin

